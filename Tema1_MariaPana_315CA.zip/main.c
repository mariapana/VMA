#include "vma.h"
#include "menu.h"

int main(void)
{
	return menu();
}
